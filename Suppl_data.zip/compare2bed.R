# Install required packages if they are not already installed
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install(c("rtracklayer", "GenomicRanges", "regioneR", "BSgenome.Hsapiens.UCSC.hg38"))

# Load necessary libraries
library(rtracklayer)
library(GenomicRanges)
library(regioneR)
library(BSgenome.Hsapiens.UCSC.hg38)

# Import the two BED files (replace with your actual file names)
bed1 <- import("/Users/mtongoss/Dropbox/Research/projects/GeneticCode_CpG/data/CpGFree/mergeLists/CHROM_STATE/coordinatesTOP100human.bed", format = "BED")
bed2 <- import("/Users/mtongoss/Dropbox/Research/projects/GeneticCode_CpG/data/CpGFree/mergeLists/CHROM_STATE/ENCFF343KUN.bed", format = "BED")

# Ensure the chromosome naming matches UCSC conventions (e.g., "chr1", "chr2", etc.)
seqlevelsStyle(bed1) <- "UCSC"
seqlevelsStyle(bed2) <- "UCSC"

# Step 2: Find overlapping regions between the two BED files
overlap_hits <- findOverlaps(bed1, bed2)

# Extract overlapping regions from each BED file
bed1_overlap <- bed1[queryHits(overlap_hits)]
bed2_overlap <- bed2[subjectHits(overlap_hits)]

# Compute the exact intersection of overlapping intervals
intersect_regions <- pintersect(bed1_overlap, bed2_overlap)

# Remove any block-specific metadata that might interfere with exporting
mcols(intersect_regions) <- NULL

# Export the intersected regions to a new BED file
export(intersect_regions, "intersection.bed", format = "BED")

# Print summary of intersections
cat("Number of regions in bed1:", length(bed1), "\n")
cat("Number of regions in bed2:", length(bed2), "\n")
cat("Number of overlapping intervals:", length(intersect_regions), "\n")

# Step 3: Permutation test to assess significance of the overlap
# This test shuffles bed1 over the genome (hg38) 1000 times to build a null distribution
pt <- overlapPermTest(A = bed1, B = bed2, ntimes = 1000, genome = BSgenome.Hsapiens.UCSC.hg38)

# Print the permutation test results
print(pt)

# Optionally, visualize the permutation test result
plot(pt)
